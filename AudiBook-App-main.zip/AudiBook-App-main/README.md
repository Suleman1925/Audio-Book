![Cover](https://github.com/ARassignments/AudiBook-App/assets/49037725/fac49f00-0fbe-4e9e-b4a7-a94b5fda9ca0)
![Light Mode (1)](https://github.com/ARassignments/AudiBook-App/assets/49037725/0321465b-3abd-4f78-8b35-bacadec26d1f)
![Dark Mode](https://github.com/ARassignments/AudiBook-App/assets/49037725/35670ce9-2e3a-4fb9-997d-9449ee0de7ff)
